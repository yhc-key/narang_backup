package com.ssafy.kafka.Controller;

import com.ssafy.kafka.producer.TestProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/kafka")
public class TestController {

    @Autowired
    private TestProducer testProducer;

    @GetMapping("send-msg")
    public void sendMsg(String message) {

        testProducer.create(message);
    }
}
